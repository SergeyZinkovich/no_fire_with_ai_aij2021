import os
import pickle
import cfgrib
import numpy as np
import pandas as pd
import geopandas as gpd
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
from catboost import Pool, CatBoostClassifier
from OSMPythonTools.nominatim import Nominatim
from OSMPythonTools.overpass import overpassQueryBuilder, Overpass

# модули из репозитория https://github.com/sberbank-ai/no_fire_with_ai_aij2021
import helpers, preprocessing, features_generation, prepare_train
from solution import FEATURES

import warnings
warnings.simplefilter("ignore")
plt.rcParams["figure.figsize"] = (16,8)

ds = cfgrib.open_datasets('input/ERA5_data/temp_2018.grib')

print(len(ds))

print(ds[0].indexes['time'].min(), ds[0].indexes['time'].max())

ds[0].stl1[200].plot(cmap=plt.cm.coolwarm)

# Может понадобиться выполнение команд
# pip uninstall shapely
# pip install shapely --no-binary shapely

ax = plt.axes(projection=ccrs.Robinson())
# ax.coastlines(resolution='10m')
plot = ds[1].d2m[119].plot(cmap=plt.cm.coolwarm, transform=ccrs.PlateCarree(), cbar_kwargs={'shrink':0.6})
plt.title('Soil temperature on 2018-04-29');

times, latitudes, longitudes = preprocessing.parse_dims(ds)

print(latitudes)

print(longitudes)

train_raw = pd.read_csv('input/train_raw.csv', parse_dates=['dt'])
print(train_raw.shape)
print(train_raw.head())


print(train_raw.dt.min(), train_raw.dt.max())

lat_min = round(latitudes.min(), 1)
lat_max = round(latitudes.max(), 1)

lon_min = round(longitudes.min(), 1)
lon_max = round(longitudes.max(), 1)

print(lat_min, lat_max, lon_min, lon_max)


step = 0.2
array_of_lats = np.arange(lat_min, lat_max, step).round(1)
array_of_lons = np.arange(lon_min, lon_max, step).round(1)
print(len(array_of_lats), len(array_of_lons))


train = pd.read_csv('input/train.csv', parse_dates=['dt'])
print(train.shape)
train.head()

print(train.dt.min(), train.dt.max())

sample_test = pd.read_csv('input/sample_test.csv', parse_dates=['dt'])
print(sample_test.shape)
print(sample_test.head())


val = train[train.dt >= "2021-02-01"].reset_index(drop=True)
train = train[train.dt < "2021-02-01"].reset_index(drop=True)
train.shape, val.shape



print(train[['infire_day_1', 'infire_day_2', 'infire_day_3',
       'infire_day_4', 'infire_day_5', 'infire_day_6',
       'infire_day_7', 'infire_day_8']].apply(pd.Series.value_counts))


print(val[['infire_day_1', 'infire_day_2', 'infire_day_3',
       'infire_day_4', 'infire_day_5', 'infire_day_6',
       'infire_day_7', 'infire_day_8']].apply(pd.Series.value_counts))


cities_df = gpd.read_file('input/city_town_village.geojson')
cities_df = cities_df[['admin_level', 'name', 'population', 'population:date', 'place', 'geometry']]
cities_df = cities_df[cities_df.place != 'city_block'].reset_index(drop=True)
cities_df['lon'] = cities_df['geometry'].x
cities_df['lat'] = cities_df['geometry'].y

cities_df.loc[cities_df.lon < 0, 'lon'] += 360
cities_df.loc[cities_df.population.notna(), 'population'] = cities_df[cities_df.population.notna()]\
                            .population.apply(helpers.split_string).str.replace(" ", "").astype(int)
print(cities_df.head())


cities_df = helpers.add_edges_polygon(cities_df)
cities_df = cities_df[(cities_df.lon_max <= lon_max) &\
                      (cities_df.lon_min >= lon_min) &\
                      (cities_df.lat_min >= lat_min) &\
                      (cities_df.lat_max <= lat_max)].reset_index(drop=True)


cities_df = helpers.get_grid_index(cities_df, array_of_lons, array_of_lats)



cities_df.rename(columns={'lon': 'city_lon',
                          'lat': 'city_lat'}, inplace=True)
print(cities_df.head())


#%%time

PATH_TO_ADD_DATA = 'additional_data/'

grib_list = [el.split('.')[0] for el in os.listdir("input/ERA5_data")\
             if el.startswith(("temp", "wind",
                               "evaporation1", "evaporation2",
                               "heat1", "heat2", "vegetation")) and el.endswith(('2020.grib'))]

for file_name in grib_list:
     preprocessing.make_pool_features("input/ERA5_data",
                                      file_name, PATH_TO_ADD_DATA)












